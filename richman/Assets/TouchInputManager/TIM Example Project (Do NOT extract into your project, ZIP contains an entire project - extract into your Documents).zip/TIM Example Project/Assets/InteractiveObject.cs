﻿using UnityEngine;
using System.Collections;

public class InteractiveObject : MonoBehaviour {

	public Color colorOnTouch;

	private float spinSpeed = 0;

	// Use this for initialization
	void Start () {

		
		//Tell TIM to pass input and render our first layout, which contains the joystick and button
		TouchInputManager.RenderLayout (LayoutID.ExampleLayout1,true);
		TouchInputManager.PassInputToLayout (LayoutID.ExampleLayout1,true);


		//We aren't going to render this layout, we only need to pass input to it 
		//This layout only contains our zone, and have nothing to render anyway
		TouchInputManager.PassInputToLayout (LayoutID.ExampleLayout2,true);

		//Not every script needs to pass input and render a layout, as long as someone does it
		//Normally pass input and render layout calls would go into one of your game manager objects


		//Random start rotation
		transform.rotation = Quaternion.Euler (Random.onUnitSphere * 360);
	}

	void Update()
	{
		//If we detect the touch button being pressed, spin the objects
		if (TouchInputManager.GetButton (InputID.ExampleButton, LayoutID.ExampleLayout1)) 
		{
			spinSpeed = 5;
		}
	}

	void FixedUpdate()
	{
		if(spinSpeed > 0)
		{
			spinSpeed-=0.25f;
			transform.Rotate(new Vector3(0,spinSpeed,0));
		}
	}


	//When tapped on, this function will get called initially
	void OnTouchEnter(Vector2 touchScreenPos)
	{
		renderer.material.color = colorOnTouch;
	}

	//and this one will get called when the finger is lifted. 
	//You can also use OnTouch, which gets called every frame that the finger down
	void OnTouchExit(Vector2 touchScreenPos)
	{
		renderer.material.color = Color.white;
	}

}
