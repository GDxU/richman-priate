- The TouchInputManager folder must be located directly in your "Assets" folder, as imported.
- OS X users will need to download and install the Mono runtime. http://www.mono-project.com/Mono:Runtime

Thank you for purchasing Touch Input Manager 2! 

Our website is at http://touchinputmanager.timaksu.com/
You can post bugs and features request at our bug tracket at http://touchinputmanager.timaksu.com/BugTracker/
A start guide can be found at http://touchinputmanager.timaksu.com/GettingStarted/
Documentation is at http://touchinputmanager.timaksu.com/Documentation
Forum can be found at http://touchinputmanager.timaksu.com/Forum

You can always contact us directly at ContactPigeonCoop@gmail.com

If you like Touch Input Manager, we would love it if you could leave a review at http://goo.gl/j0oUG