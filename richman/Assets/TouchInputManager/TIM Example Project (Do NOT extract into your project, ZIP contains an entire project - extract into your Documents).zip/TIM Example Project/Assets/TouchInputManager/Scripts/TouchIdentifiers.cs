public enum LayoutID
{
    ExampleLayout2 = 0,
    ExampleLayout1 = 1,
}
public enum InputID
{
    ExampleZone = 0,
    ExampleStick = 1,
    ExampleButton = 2,
}
