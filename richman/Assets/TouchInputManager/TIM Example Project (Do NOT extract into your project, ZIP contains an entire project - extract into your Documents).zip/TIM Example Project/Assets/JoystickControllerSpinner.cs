﻿using UnityEngine;
using System.Collections;

public class JoystickControllerSpinner : MonoBehaviour {

	void Start () {
		//Tell TIM to pass input and render our first layout, which contains the joystick and button
		TouchInputManager.RenderLayout (LayoutID.ExampleLayout1,true);
		TouchInputManager.PassInputToLayout (LayoutID.ExampleLayout1,true);
	}

	// Update is called once per frame
	void FixedUpdate () {

		Vector2 input = TouchInputManager.GetJoystick(InputID.ExampleStick,LayoutID.ExampleLayout1);
		transform.Rotate (new Vector3 (input.y, -input.x, 0));

	}
}
