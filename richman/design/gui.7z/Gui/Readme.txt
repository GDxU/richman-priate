All graphics in this folder including sources, is under CCO license, that means you can do whatever you want with them. 

Some of the sources is not included because i lost them.

I would be greatful if you email me at DustyChest@gmail.com and inform, where are you using these graphics. :)

Good luck with your projects! :)


My website(blog): http://dustychest.blogspot.com/

Contact: DustyChest@gmail.com
